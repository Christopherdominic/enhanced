import React from 'react';
import { auth, provider, signInWithPopup } from './firebase';

function Login() {
  const login = async () => {
    await signInWithPopup(auth, provider);
  };

  return <button onClick={login}>Login with Google</button>;
}

export default Login;
