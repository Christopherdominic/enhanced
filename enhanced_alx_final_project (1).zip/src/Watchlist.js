import React, { useState } from 'react';

function Watchlist() {
  const [watchlist, setWatchlist] = useState([]);
  const [category, setCategory] = useState('To Watch');

  const addToWatchlist = (movie) => {
    setWatchlist([...watchlist, { ...movie, category }]);
  };

  return (
    <div>
      <select onChange={(e) => setCategory(e.target.value)}>
        <option value="To Watch">To Watch</option>
        <option value="Watched">Watched</option>
      </select>
      <ul>
        {watchlist.map((item, index) => (
          <li key={index}>{item.title} - {item.category}</li>
        ))}
      </ul>
    </div>
  );
}

export default Watchlist;
