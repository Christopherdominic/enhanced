import React, { useState } from 'react';
import axios from 'axios';

function MovieSearch() {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);

  const fetchSuggestions = async (query) => {
    const { data } = await axios.get(`https://api.themoviedb.org/3/search/movie`, {
      params: { api_key: 'YOUR_API_KEY', query },
    });
    setSuggestions(data.results);
  };

  const handleChange = (e) => {
    setQuery(e.target.value);
    if (e.target.value.length > 2) fetchSuggestions(e.target.value);
  };

  return (
    <div>
      <input type="text" value={query} onChange={handleChange} placeholder="Search movies..." />
      <ul>
        {suggestions.map((movie) => (
          <li key={movie.id}>{movie.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default MovieSearch;
