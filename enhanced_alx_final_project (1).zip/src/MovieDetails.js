import React, { useEffect, useState } from 'react';
import axios from 'axios';

function MovieDetails({ movieId }) {
  const [trailer, setTrailer] = useState('');

  useEffect(() => {
    const fetchTrailer = async () => {
      const { data } = await axios.get(`https://www.googleapis.com/youtube/v3/search`, {
        params: {
          part: 'snippet',
          q: `${movieId} trailer`,
          key: 'YOUR_YOUTUBE_API_KEY',
        },
      });
      setTrailer(data.items[0].id.videoId);
    };

    fetchTrailer();
  }, [movieId]);

  return (
    <div>
      <iframe
        width="560"
        height="315"
        src={`https://www.youtube.com/embed/${trailer}`}
        title="Movie Trailer"
        allowFullScreen
      ></iframe>
    </div>
  );
}

export default MovieDetails;
